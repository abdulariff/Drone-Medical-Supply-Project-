%% Trajectory Analysis Script
% Stewart Isaacs - February 6, 2020
% Modified and Repurposed by Abdul Sabit Ariff

clc
close all
clear all

%% Universal Constants
roh = 1.225; %[kg/m^3] - Air Density
pi = 3.14159265;
g = 9.80; %[m/s^2] - Acceleration due to gravity
t_step = 0.05; %[seconds] = Half second time step

%% Design Parameters
Cd = 1.0; % [-] Co-efficient of drag

% Payload box 
l_box = 0.35; %[m]
w_box = 0.35; %[m]
h_box = 0.35; %[m]
FA_pay = h_box * w_box; % Frontal area of box[m^2]
m_pay = 1.914375; %[kg]  Mass of payload(including box, medicines, foam padding)
foam_force = 0; %[N] Force absorbed by foam padding (Can go up to 160N)

% Parachute
rho_nylon = 1150; % [kg/m^3] Density of nylon
d_para = 0.191063; % [m] Diameter of parachute
V_para = (pi * d_para^3)/12; % [m^2] Volume of parachute
m_para = rho_nylon * V_para; % [kg] Mass of parachute
FA_para = (pi * d_para^2)/4; % [m^2] Frontal area of parachute

% Winch System
a_rope = 0.0375; % [m/s^2] Acceleration of Winch System Rope
n_rope = 1; % [-] Number of ropes 
e = 0.95; % [-] Efficiency of winch system
T = (m_pay*g)/ (n_rope * e); %[N] Tension in Winch System

%% Initial Conditions
i = 1;
t = 0;
h_0 = 10; % [m] - Initial Height/ Cruising Altitude for Drone
v_0 = 11; % [m/s] - Initial Velocity

%% Analysis
y_obj = h_0;%[m]
x_obj = -12;
v = v_0;
simulation_mat = [];

while y_obj > 0
    if i == 1
        t = 0;
    else
        t = t + t_step;
    end
    
   
 % Determine Y component
    a_winch = g * ((1/(n_rope*e))-1) - (a_rope/m_pay); % Downward Acceleration of rope system
    D_para = - (Cd * roh * FA_para * v^2)/2; % Drag force on parachute
    a_para = (Cd*roh*FA_para*(v^2))/(2*(m_para+m_pay))- g; % Acceleration due to vertical drag force on parachute
    
    if x_obj > 0 % Detaching the rope from payload to switch to parachute
        a_winch = 0;
    else
        a_para = 0;
    end
    
    a = a_winch + a_para;
    y_obj = y_obj + 0.5*a*t^2;
    
    
     % Determine velocity
    D(i) = 0.5 * roh * FA_pay * Cd * v^2; % Horizontal drag force on payload box
    a_x = D(i) ./ m_pay;
    v = v - a_x*t_step; 
    x_obj = x_obj + v*t_step;

    % Store in Matrix
    simulation_mat(i,1) = t;
    simulation_mat(i,2)= y_obj;
    simulation_mat(i,3)= x_obj;
    simulation_mat(i,4) = v;
    i = i+1;
   end
Impact_F = foam_force + ((m_pay+m_para) * a); % This estimates the force with which the payload hits the ground
%disp("The payload hits ground with a force of " + Impact_F + "N without the foam padding");
%% Visualization
% Animated Plot to help visualize
plot(simulation_mat(1,3),simulation_mat(1,2),'r*');
ymax = h_0+(0.5*h_0);
xmax = v_0*t + 0.5*v_0*t;
ymax = 50;
xmax = 100;
xlim([-10 xmax])
ylim([0 ymax])
axis([-25 50 0 30])
[row,col] = size(simulation_mat);
for i = 2:length(simulation_mat)
    plot(simulation_mat(i,3),simulation_mat(i,2),'r*');
    xlim([-10 xmax])
    ylim([0 ymax])
    axis([-25 50 0 30])
    pause(simulation_mat(row)/row);
end
% Leave a plot of the full trajectory
plot(simulation_mat(:,3),simulation_mat(:,2));
text(x_obj-20,h_0+7,"Impact Force without foam padding: " + Impact_F + "N"); % Displaying Impact Force on plot
title('Payload Trajectory(Final Design)')
ylabel('Height (m)')
xlabel('Distance from dropzone (m)')
ymax = 50;
xmax = 100;
xlim([-10 xmax])
ylim([0 ymax])
axis([-25 50 0 30])